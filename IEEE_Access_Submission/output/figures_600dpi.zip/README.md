# Submission figures

Vector PDFs are the actual figures included in the manuscript. PNG copies are rendered from those PDFs at at least 600 pixels per inch at their LaTeX display widths. PNG density metadata may read 599.9988 because of integer pixels-per-meter storage. Captions remain in the manuscripts.

| Figure | File stem |
|---|---|
| 1 | fig_architecture |
| 2 | fig_efficiency |
| 3 | fig_ibam_map |
| 4 | fig_localization_forest |
| 5 | fig_interaction_content |
| 6 | fig_docking |
| 7 | fig_generation |
| 8 | fig_top_analogs |
| 9 | fig_benchmark_validity |
| S1 | fig_residual_diagnostics |
| S2 | fig_ablation_scaffold_summary |

See figure_validation.json for dimensions, text sizes, and SHA-256 hashes. Automated packaging does not replace visual review.
