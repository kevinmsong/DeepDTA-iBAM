# IEEE Access submission source

This archive contains only the active manuscript, supplement, combined wrapper, bibliography, required local template assets, tables, and included vector figures. It excludes checkpoints, training data, caches, obsolete drafts, and build auxiliaries.

Install a current TeX distribution with pdfLaTeX, BibTeX, and the packages used by the sources. Official IEEE template assets are retained unchanged.

Run the following from `the archive root` after extracting:

```text
pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error supplementary.tex
bibtex supplementary
pdflatex -interaction=nonstopmode -halt-on-error supplementary.tex
pdflatex -interaction=nonstopmode -halt-on-error supplementary.tex
pdflatex -interaction=nonstopmode -halt-on-error combined.tex
pdflatex -interaction=nonstopmode -halt-on-error combined.tex
```

Outputs are main.pdf, supplementary.pdf, and combined.pdf. Run BibTeX again if the bibliography changes. Render and visually inspect the final PDFs before submission. This source archive rebuilds the documents from saved figures; it does not rerun model analyses.
